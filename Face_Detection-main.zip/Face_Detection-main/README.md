# Face_Detection
Implementation of a system for identifying and locating a face from an image
