# License_Plate_Localization_Algorithm
This Algorithm runs on the PYNQ FPGA Board , it onlt use OpenCV, MatplotLib etc. So, it also work well in the Anaconda-Jupyter-Notebook at PC!
