# BNN_based_Character_Recognition_System_with_PYNQ_FPGA
BNN based Character Recognition System with PYNQ FPGA This notebook uses Binary Neural Networks on Pynq.  For more information about the BNN, please visit BNN PYNQ Project at Github: https://github.com/Xilinx/BNN-PYNQ
