# LEDs_Control_PYNQ_Z2
PYNQ_Z2-Based LED Control and Monitoring
